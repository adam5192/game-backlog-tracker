"use client";

import { useMemo, useState } from "react";
import GameDetailModal from "./GameDetailModal";
import Image from "next/image";
import RecommendationCard from "@/components/RecommendationCard";

// matches gamedetailmodal shape, build from joined drizzle query results
type GameDetail = {
  userGameId: string;
  gameId: string;
  igdbId: number;
  name: string;
  coverUrl: string | null;
  artworkUrl: string | null;
  description: string | null;
  criticScore: number | null;
  hltbMain: number | null;
  hltbMainExtra: number | null;
  hltbCompletionist: number | null;
  status: string;
  rating: number | null;
  notes: string | null;
  genres: string[];
  createdAt: string;
  releaseDate: string | null;
};

// receives already-fetched list as a prop
type Props = {
  games: GameDetail[];
};

const STATUSES = ["all", "backlog", "playing", "completed", "dropped"] as const;
type StatusFilter = (typeof STATUSES)[number];

type SortOption = "recent" | "name" | "rating" | "critic" | "release" | "hltb";

export default function GameList({ games }: Props) {
  // tracks which game is currently open in the modal
  const [selectedGame, setSelectedGame] = useState<GameDetail | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [search, setSearch] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<SortOption>("recent");

  // recomputes list of unique gernes only when 'games' actually changes
  const availableGenres = useMemo(() => {
    const set = new Set<string>();
    games.forEach((g) => g.genres.forEach((genre) => set.add(genre)));
    return Array.from(set).sort();
  }, [games]);

  // also memoized so it doesnt re-run on every single render
  const filteredGames = useMemo(() => {
    let result = games;

    if (statusFilter !== "all") {
      result = result.filter((g) => g.status === statusFilter);
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((g) => g.name.toLowerCase().includes(q));
    }

    if (selectedGenre) {
      result = result.filter((g) => g.genres.includes(selectedGenre));
    }

    const sorted = [...result].sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "rating":
          // -1 so unrated games sort to the bottom
          return (b.rating ?? -1) - (a.rating ?? -1);
        case "critic":
          return (b.criticScore ?? -1) - (a.criticScore ?? -1);
        case "release":
          // missing release dates sort last
          return (
            new Date(b.releaseDate ?? 0).getTime() -
            new Date(a.releaseDate ?? 0).getTime()
          );
        case "hltb":
          return (b.hltbMain ?? -1) - (a.hltbMain ?? -1);
        case "recent":
        default:
          return (
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
      }
    });

    return sorted;
  }, [games, statusFilter, search, selectedGenre, sortBy]);

  return (
    <>
      {/* search + sort row */}
      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <input
          className="bg-surface-1 text-foreground placeholder-text-secondary px-4 py-2 rounded-lg flex-1 border border-border-color focus:border-accent outline-none transition-colors"
          placeholder="Search your games..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="bg-surface-1 text-foreground px-4 py-2 rounded-lg w-full sm:w-48 border border-border-color focus:border-accent outline-none transition-colors"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as SortOption)}
        >
          <option value="recent">Recently added</option>
          <option value="name">Name (A-Z)</option>
          <option value="rating">Your rating</option>
          <option value="critic">Critic score</option>
          <option value="release">Release date</option>
          <option value="hltb">Hours to beat</option>
        </select>
      </div>

      {/* genre chips */}
      {availableGenres.length > 0 && (
        <div className="flex gap-2 flex-wrap mb-3">
          <button
            onClick={() => setSelectedGenre(null)}
            className={`text-xs px-3 py-1 rounded-full transition-colors ${
              selectedGenre === null
                ? "bg-accent text-accent-foreground"
                : "border border-border-color text-text-secondary hover:text-foreground hover:bg-surface-1"
            }`}
          >
            All
          </button>
          {availableGenres.map((genre) => (
            <button
              key={genre}
              onClick={() =>
                setSelectedGenre(genre === selectedGenre ? null : genre)
              }
              // clicking the already-selected genre toggles it back off
              className={`text-xs px-3 py-1 rounded-full transition-colors ${
                selectedGenre === genre
                  ? "bg-accent text-accent-foreground"
                  : "border border-border-color text-text-secondary hover:text-foreground hover:bg-surface-1"
              }`}
            >
              {genre}
            </button>
          ))}
        </div>
      )}

      {/* status tabs */}
      <div className="flex gap-2 flex-nowrap overflow-x-auto border-b border-border-color pb-3 mb-4">
        {STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`capitalize text-sm px-4 py-1.5 rounded-full transition-colors whitespace-nowrap shrink-0 hover:bg-surface-1 hover:text-foreground ${
              statusFilter === s
                ? "bg-accent text-accent-foreground"
                : "border border-border-color text-foreground"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <RecommendationCard />

      {filteredGames.length === 0 ? (
        <p className="text-text-secondary text-sm">
          No games match your filters.
        </p>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 xl:grid-cols-8 gap-3">
          {filteredGames.map((game) => (
            <button
              key={game.userGameId}
              className="text-left border border-border-color rounded-lg overflow-hidden transition-all duration-200 hover:border-accent hover:-translate-y-1 hover:shadow-lg"
              onClick={() => setSelectedGame(game)}
            >
              <div className="aspect-3/4 bg-surface-2 relative">
                {game.coverUrl && (
                  <Image
                    src={game.coverUrl}
                    alt={game.name}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 33vw, 16vw"
                  />
                )}
              </div>
              <div className="p-2">
                <p className="text-sm font-medium truncate text-foreground">
                  {game.name}
                </p>
                {/* show status badge always when viewing "All" */}
                <p className="text-xs text-text-secondary capitalize">
                  {game.status}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}

      {selectedGame && (
        <GameDetailModal
          game={selectedGame}
          onClose={() => setSelectedGame(null)}
        />
      )}
    </>
  );
}
